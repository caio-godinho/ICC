typedef struct{
    int len;
    int *vals;
} vetor;