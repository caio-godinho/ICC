vetor *cria_vetor(int tamanho);

void ler_vetor(vetor *v);

vetor *retorna_vetor(void);

vetor *vetor_intercalado(vetor *a, vetor *b);

void print_vetor(vetor *v);

void destruir_vetor(vetor *v);