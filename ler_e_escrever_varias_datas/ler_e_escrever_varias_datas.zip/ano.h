#ifndef __ANO_H__
#define __ANO_H__

void ano(data *p);

#endif