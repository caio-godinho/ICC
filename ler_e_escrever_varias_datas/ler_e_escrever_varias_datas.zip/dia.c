#include<stdio.h>
#include"struct.h"

void dia(data *p){
    printf("%02d de ", p->dia);
}