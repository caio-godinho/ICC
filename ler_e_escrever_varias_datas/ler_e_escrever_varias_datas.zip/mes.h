#ifndef __MES_H__
#define __MES_H__

void mes(data *p);

#endif