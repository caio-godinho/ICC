#ifndef __DIA_H__
#define __DIA_H__

void dia(data *p);

#endif