#include<stdio.h>
#include"struct.h"

void ano(data *p){
   printf("%04d\n", p->ano);
      
}