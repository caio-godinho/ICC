#ifndef __STRUCT_H__
#define __STRUCT_H__

typedef struct{
   int dia;
   int mes;
   int ano;
} data;

#endif