#ifndef __INVALIDA_H__
#define __INVALIDA_H__

int bissexto(int ano);
int data_invalida(data *p);

#endif