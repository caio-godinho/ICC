#ifndef __LER_H__
#define __LER_H__

void ler_matriz(matriz *m);

#endif