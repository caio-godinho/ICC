#ifndef __TRASNPOSTA_H__
#define __TRANSPOSTA_H__
void print_transposta(matriz *m);

#endif