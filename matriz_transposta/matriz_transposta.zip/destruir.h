#ifndef __DESTRUIR_H__
#define __DESTRUIR_H__

void destruir_matriz(matriz *m);

#endif