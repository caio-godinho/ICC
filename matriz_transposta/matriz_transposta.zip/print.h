#ifndef __PRINT_H__
#define __PRINT_H__

void print_matriz(matriz *m);

#endif