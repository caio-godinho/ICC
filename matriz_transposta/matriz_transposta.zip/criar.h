#ifndef __CRIAR_H__
#define __CRIAR_H__

matriz *criar_matriz(int nl, int nc);

#endif